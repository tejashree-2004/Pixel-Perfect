/**
 * Quiz State Management Hook
 * Handles all quiz logic including navigation, answers, and scoring
 */

import { useState, useCallback, useMemo } from "react";
import { QUIZ_QUESTIONS, type Question } from "@/constants/quiz";

export type QuizState = "idle" | "active" | "completed";

interface UseQuizReturn {
  state: QuizState;
  currentQuestionIndex: number;
  currentQuestion: Question;
  selectedAnswers: Record<number, number>;
  totalQuestions: number;
  score: number;
  scorePercentage: number;
  isFirstQuestion: boolean;
  isLastQuestion: boolean;
  canSubmit: boolean;
  startQuiz: () => void;
  selectAnswer: (questionId: number, answerIndex: number) => void;
  goToNextQuestion: () => void;
  goToPreviousQuestion: () => void;
  submitQuiz: () => void;
  restartQuiz: () => void;
}

export function useQuiz(): UseQuizReturn {
  const [state, setState] = useState<QuizState>("idle");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});

  const totalQuestions = QUIZ_QUESTIONS.length;
  const currentQuestion = QUIZ_QUESTIONS[currentQuestionIndex];
  const isFirstQuestion = currentQuestionIndex === 0;
  const isLastQuestion = currentQuestionIndex === totalQuestions - 1;
  
  const canSubmit = useMemo(() => {
    return Object.keys(selectedAnswers).length === totalQuestions;
  }, [selectedAnswers, totalQuestions]);

  const score = useMemo(() => {
    return QUIZ_QUESTIONS.reduce((acc, question) => {
      const selectedAnswer = selectedAnswers[question.id];
      return selectedAnswer === question.correctAnswer ? acc + 1 : acc;
    }, 0);
  }, [selectedAnswers]);

  const scorePercentage = useMemo(() => {
    return Math.round((score / totalQuestions) * 100);
  }, [score, totalQuestions]);

  const startQuiz = useCallback(() => {
    setState("active");
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
  }, []);

  const selectAnswer = useCallback((questionId: number, answerIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: answerIndex,
    }));
  }, []);

  const goToNextQuestion = useCallback(() => {
    if (!isLastQuestion) {
      setCurrentQuestionIndex((prev) => prev + 1);
    }
  }, [isLastQuestion]);

  const goToPreviousQuestion = useCallback(() => {
    if (!isFirstQuestion) {
      setCurrentQuestionIndex((prev) => prev - 1);
    }
  }, [isFirstQuestion]);

  const submitQuiz = useCallback(() => {
    if (canSubmit) {
      setState("completed");
    }
  }, [canSubmit]);

  const restartQuiz = useCallback(() => {
    setState("idle");
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
  }, []);

  return {
    state,
    currentQuestionIndex,
    currentQuestion,
    selectedAnswers,
    totalQuestions,
    score,
    scorePercentage,
    isFirstQuestion,
    isLastQuestion,
    canSubmit,
    startQuiz,
    selectAnswer,
    goToNextQuestion,
    goToPreviousQuestion,
    submitQuiz,
    restartQuiz,
  };
}
