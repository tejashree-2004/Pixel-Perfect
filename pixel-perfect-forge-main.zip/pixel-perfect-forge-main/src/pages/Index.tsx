/**
 * Index Page
 * Knowledge Quiz - Frontend Intern Assignment
 * 
 * A pixel-perfect, accessible, and beautifully animated quiz application
 * showcasing production-quality React component architecture.
 */

import { QuizContainer } from "@/components/quiz/QuizContainer";

const Index = () => {
  return <QuizContainer />;
};

export default Index;
