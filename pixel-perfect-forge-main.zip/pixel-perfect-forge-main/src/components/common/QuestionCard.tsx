/**
 * Question Card Component
 * Displays the current quiz question with number
 */

import { motion, AnimatePresence } from "framer-motion";
import type { Question } from "@/constants/quiz";

interface QuestionCardProps {
  question: Question;
  questionIndex: number;
}

export function QuestionCard({ question, questionIndex }: QuestionCardProps) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={question.id}
        className="bg-secondary rounded-xl px-6 py-4 mb-4"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        role="heading"
        aria-level={2}
      >
        <p className="text-center text-card-foreground font-medium">
          <span className="text-muted-foreground">{questionIndex + 1}. </span>
          {question.question}
        </p>
      </motion.div>
    </AnimatePresence>
  );
}
