/**
 * Mascot Component
 * Cute cat paw mascot with speech bubble
 */

import { motion } from "framer-motion";

export function Mascot() {
  return (
    <motion.div
      className="fixed bottom-8 left-8 z-10"
      initial={{ opacity: 0, y: 50, scale: 0.8 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        delay: 0.5, 
        duration: 0.5, 
        type: "spring",
        stiffness: 200 
      }}
    >
      {/* Speech bubble */}
      <motion.div
        className="relative bg-card text-card-foreground px-4 py-2 rounded-2xl shadow-card mb-2 font-display italic text-sm"
        animate={{ y: [0, -5, 0] }}
        transition={{ 
          duration: 2, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
      >
        Best of Luck!
        {/* Bubble tail */}
        <div className="absolute -bottom-2 left-4 w-4 h-4 bg-card transform rotate-45" />
      </motion.div>

      {/* Cat paw */}
      <motion.div
        className="w-20 h-24 relative"
        animate={{ rotate: [-5, 5, -5] }}
        transition={{ 
          duration: 3, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
        aria-hidden="true"
      >
        {/* Paw base */}
        <svg viewBox="0 0 80 100" className="w-full h-full">
          {/* Main paw pad */}
          <ellipse cx="40" cy="70" rx="30" ry="25" fill="hsl(0 0% 95%)" />
          
          {/* Toe beans */}
          <circle cx="22" cy="45" r="12" fill="hsl(350 70% 85%)" />
          <circle cx="40" cy="38" r="12" fill="hsl(350 70% 85%)" />
          <circle cx="58" cy="45" r="12" fill="hsl(350 70% 85%)" />
          
          {/* Center pad */}
          <ellipse cx="40" cy="72" rx="15" ry="12" fill="hsl(350 70% 85%)" />
          
          {/* Highlight */}
          <ellipse cx="35" cy="68" rx="6" ry="4" fill="hsl(350 70% 90%)" opacity="0.6" />
        </svg>
      </motion.div>
    </motion.div>
  );
}
