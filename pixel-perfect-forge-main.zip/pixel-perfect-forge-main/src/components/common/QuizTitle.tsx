/**
 * Quiz Title Component
 * Elegant typography for the quiz header
 */

import { motion } from "framer-motion";
import { QUIZ_CONFIG } from "@/constants/quiz";

interface QuizTitleProps {
  subtitle?: string;
}

export function QuizTitle({ subtitle = QUIZ_CONFIG.subtitle }: QuizTitleProps) {
  return (
    <motion.header
      className="text-center mb-8"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <h1 className="font-display text-4xl md:text-5xl lg:text-6xl text-primary mb-4">
        <span className="italic">{QUIZ_CONFIG.title}</span>{" "}
        <span className="font-semibold italic">{QUIZ_CONFIG.titleHighlight}</span>
      </h1>
      
      <motion.p
        className="inline-block px-6 py-2 bg-secondary/50 rounded-full text-muted-foreground text-sm md:text-base"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.3 }}
      >
        {subtitle}
      </motion.p>
    </motion.header>
  );
}
