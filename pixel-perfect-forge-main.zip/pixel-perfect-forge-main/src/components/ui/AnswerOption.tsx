/**
 * Answer Option Component
 * Accessible, animated answer button for quiz questions
 */

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface AnswerOptionProps {
  option: string;
  index: number;
  isSelected: boolean;
  onSelect: () => void;
  disabled?: boolean;
}

export function AnswerOption({ 
  option, 
  index, 
  isSelected, 
  onSelect,
  disabled = false 
}: AnswerOptionProps) {
  return (
    <motion.button
      type="button"
      onClick={onSelect}
      disabled={disabled}
      className={cn(
        "answer-option w-full text-center font-medium",
        "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
      )}
      data-selected={isSelected}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.3, 
        delay: index * 0.08,
        ease: [0.4, 0, 0.2, 1]
      }}
      whileHover={{ 
        scale: 1.01,
        transition: { duration: 0.2 }
      }}
      whileTap={{ scale: 0.99 }}
      role="radio"
      aria-checked={isSelected}
      aria-label={`Option: ${option}`}
    >
      <span className="relative z-10">{option}</span>
      
      {/* Selection indicator */}
      {isSelected && (
        <motion.div
          className="absolute inset-0 rounded-xl border-2 border-primary bg-primary/5"
          layoutId="selectedOption"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
        />
      )}
    </motion.button>
  );
}
