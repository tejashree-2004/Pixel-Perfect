/**
 * Progress Bar Component
 * Segmented progress indicator for quiz navigation
 */

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface ProgressBarProps {
  currentStep: number;
  totalSteps: number;
  className?: string;
}

export function ProgressBar({ currentStep, totalSteps, className }: ProgressBarProps) {
  return (
    <div 
      className={cn("flex items-center gap-2", className)}
      role="progressbar"
      aria-valuenow={currentStep + 1}
      aria-valuemin={1}
      aria-valuemax={totalSteps}
      aria-label={`Question ${currentStep + 1} of ${totalSteps}`}
    >
      {Array.from({ length: totalSteps }, (_, index) => {
        const isActive = index <= currentStep;
        const isCurrent = index === currentStep;

        return (
          <motion.div
            key={index}
            className={cn(
              "h-1 flex-1 rounded-full transition-colors duration-300",
              isActive ? "bg-primary" : "bg-border"
            )}
            initial={false}
            animate={{
              scaleX: isCurrent ? 1 : 1,
              backgroundColor: isActive 
                ? "hsl(var(--primary))" 
                : "hsl(var(--border))",
            }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          />
        );
      })}
    </div>
  );
}
