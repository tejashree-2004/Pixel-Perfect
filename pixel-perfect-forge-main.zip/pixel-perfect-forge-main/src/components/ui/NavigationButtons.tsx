/**
 * Navigation Buttons Component
 * Previous/Next navigation for quiz questions
 */

import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavigationButtonsProps {
  onPrevious: () => void;
  onNext: () => void;
  canGoPrevious: boolean;
  canGoNext: boolean;
  showSubmit?: boolean;
  onSubmit?: () => void;
  className?: string;
}

export function NavigationButtons({
  onPrevious,
  onNext,
  canGoPrevious,
  canGoNext,
  showSubmit = false,
  onSubmit,
  className,
}: NavigationButtonsProps) {
  return (
    <div className={cn("flex items-center justify-end gap-3", className)}>
      <motion.button
        type="button"
        onClick={onPrevious}
        disabled={!canGoPrevious}
        className="nav-button"
        whileHover={canGoPrevious ? { scale: 1.05 } : {}}
        whileTap={canGoPrevious ? { scale: 0.95 } : {}}
        aria-label="Previous question"
        title="Previous question"
      >
        <ChevronLeft className="w-5 h-5" aria-hidden="true" />
      </motion.button>

      {showSubmit ? (
        <motion.button
          type="button"
          onClick={onSubmit}
          className="btn-primary"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          aria-label="Submit quiz"
        >
          Submit
        </motion.button>
      ) : (
        <motion.button
          type="button"
          onClick={onNext}
          disabled={!canGoNext}
          className="nav-button"
          whileHover={canGoNext ? { scale: 1.05 } : {}}
          whileTap={canGoNext ? { scale: 0.95 } : {}}
          aria-label="Next question"
          title="Next question"
        >
          <ChevronRight className="w-5 h-5" aria-hidden="true" />
        </motion.button>
      )}
    </div>
  );
}
