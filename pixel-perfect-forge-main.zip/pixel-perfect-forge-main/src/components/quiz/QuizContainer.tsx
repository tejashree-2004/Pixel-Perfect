/**
 * Quiz Container Component
 * Main orchestrator for quiz state and rendering
 */

import { AnimatePresence } from "framer-motion";
import { useQuiz } from "@/hooks/useQuiz";
import { StarryBackground } from "@/components/layout/StarryBackground";
import { Mascot } from "@/components/common/Mascot";
import { QuizQuestion } from "./QuizQuestion";
import { QuizResult } from "./QuizResult";

export function QuizContainer() {
  const {
    state,
    currentQuestionIndex,
    currentQuestion,
    selectedAnswers,
    totalQuestions,
    scorePercentage,
    isFirstQuestion,
    isLastQuestion,
    startQuiz,
    selectAnswer,
    goToNextQuestion,
    goToPreviousQuestion,
    submitQuiz,
    restartQuiz,
  } = useQuiz();

  // Auto-start the quiz for this demo
  if (state === "idle") {
    startQuiz();
    return null;
  }

  return (
    <div className="relative min-h-screen flex items-center justify-center p-6">
      <StarryBackground />
      
      {/* Skip to main content link for accessibility */}
      <a
        href="#quiz-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 
                   bg-primary text-primary-foreground px-4 py-2 rounded-lg z-50"
      >
        Skip to main content
      </a>

      <main id="quiz-content" className="relative z-10 w-full">
        <AnimatePresence mode="wait">
          {state === "active" && (
            <QuizQuestion
              key={`question-${currentQuestion.id}`}
              question={currentQuestion}
              questionIndex={currentQuestionIndex}
              totalQuestions={totalQuestions}
              selectedAnswer={selectedAnswers[currentQuestion.id]}
              onSelectAnswer={selectAnswer}
              onPrevious={goToPreviousQuestion}
              onNext={goToNextQuestion}
              onSubmit={submitQuiz}
              isFirstQuestion={isFirstQuestion}
              isLastQuestion={isLastQuestion}
            />
          )}

          {state === "completed" && (
            <div className="w-full max-w-3xl mx-auto quiz-card">
              <QuizResult
                scorePercentage={scorePercentage}
                onRestart={restartQuiz}
              />
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Mascot only on first question */}
      {state === "active" && isFirstQuestion && <Mascot />}
    </div>
  );
}
