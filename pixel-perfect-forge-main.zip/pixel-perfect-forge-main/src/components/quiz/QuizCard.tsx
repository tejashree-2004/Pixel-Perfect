/**
 * Quiz Card Component
 * Main container for quiz content with animations
 */

import { motion } from "framer-motion";
import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface QuizCardProps {
  children: ReactNode;
  className?: string;
}

export function QuizCard({ children, className }: QuizCardProps) {
  return (
    <motion.div
      className={cn("quiz-card w-full max-w-3xl mx-auto", className)}
      initial={{ opacity: 0, y: 30, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ 
        duration: 0.5, 
        ease: [0.4, 0, 0.2, 1] 
      }}
      role="main"
      aria-label="Quiz card"
    >
      {children}
    </motion.div>
  );
}
