/**
 * Quiz Result Component
 * Displays final score with celebratory animations
 */

import { motion } from "framer-motion";
import { QUIZ_CONFIG } from "@/constants/quiz";

interface QuizResultProps {
  scorePercentage: number;
  onRestart: () => void;
}

export function QuizResult({ scorePercentage, onRestart }: QuizResultProps) {
  return (
    <motion.div
      className="text-center py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {/* Keep Learning Badge */}
      <motion.div
        className="inline-block px-6 py-2 bg-secondary rounded-full text-muted-foreground text-sm mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
      >
        {QUIZ_CONFIG.keepLearningText}
      </motion.div>

      {/* Score Title */}
      <motion.h1
        className="font-display text-3xl md:text-4xl text-primary italic mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.4 }}
      >
        {QUIZ_CONFIG.scorePrefix}
      </motion.h1>

      {/* Score Display */}
      <motion.div
        className="flex items-baseline justify-center gap-2 mb-12"
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ 
          delay: 0.5, 
          duration: 0.6,
          type: "spring",
          stiffness: 200
        }}
      >
        <span className="font-display text-8xl md:text-9xl font-bold text-primary">
          {scorePercentage}
        </span>
        <span className="font-display text-4xl md:text-5xl text-primary italic">
          %
        </span>
      </motion.div>

      {/* Restart Button */}
      <motion.button
        type="button"
        onClick={onRestart}
        className="btn-primary"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.4 }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        aria-label="Start quiz again"
      >
        {QUIZ_CONFIG.restartButtonText}
      </motion.button>
    </motion.div>
  );
}
