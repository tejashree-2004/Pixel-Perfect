/**
 * Quiz Question Component
 * Displays current question with answer options and navigation
 */

import { motion } from "framer-motion";
import { QuizTitle } from "@/components/common/QuizTitle";
import { QuestionCard } from "@/components/common/QuestionCard";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { AnswerOption } from "@/components/ui/AnswerOption";
import { NavigationButtons } from "@/components/ui/NavigationButtons";
import { QuizCard } from "./QuizCard";
import type { Question } from "@/constants/quiz";

interface QuizQuestionProps {
  question: Question;
  questionIndex: number;
  totalQuestions: number;
  selectedAnswer: number | undefined;
  onSelectAnswer: (questionId: number, answerIndex: number) => void;
  onPrevious: () => void;
  onNext: () => void;
  onSubmit: () => void;
  isFirstQuestion: boolean;
  isLastQuestion: boolean;
}

export function QuizQuestion({
  question,
  questionIndex,
  totalQuestions,
  selectedAnswer,
  onSelectAnswer,
  onPrevious,
  onNext,
  onSubmit,
  isFirstQuestion,
  isLastQuestion,
}: QuizQuestionProps) {
  const hasAnswer = selectedAnswer !== undefined;

  return (
    <QuizCard>
      <QuizTitle />

      <ProgressBar
        currentStep={questionIndex}
        totalSteps={totalQuestions}
        className="mb-8"
      />

      <QuestionCard question={question} questionIndex={questionIndex} />

      <motion.div
        className="space-y-3 mb-8"
        role="radiogroup"
        aria-label={`Answers for question ${questionIndex + 1}`}
      >
        {question.options.map((option, index) => (
          <AnswerOption
            key={`${question.id}-${index}`}
            option={option}
            index={index}
            isSelected={selectedAnswer === index}
            onSelect={() => onSelectAnswer(question.id, index)}
          />
        ))}
      </motion.div>

      <NavigationButtons
        onPrevious={onPrevious}
        onNext={onNext}
        canGoPrevious={!isFirstQuestion}
        canGoNext={!isLastQuestion && hasAnswer}
        showSubmit={isLastQuestion && hasAnswer}
        onSubmit={onSubmit}
      />
    </QuizCard>
  );
}
